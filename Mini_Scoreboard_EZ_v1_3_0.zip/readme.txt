Meaning of labels:

(p) : Principal information (general)
(s) : Separate  information 
PT1 : Union of P1 (Player 1) or T1 (Team 1)
PT2 : Union of P2 (Player 2) or T2 (Team 2)
--------------------------------------------
Significados de etiquetas:

(p) : Informacion principal (general)
(s) : Informacion separada
PT1 : Union de P1 (Player 1) or T1 (Team 1)
PT1 : Union de P2 (Player 2) or T2 (Team 2)